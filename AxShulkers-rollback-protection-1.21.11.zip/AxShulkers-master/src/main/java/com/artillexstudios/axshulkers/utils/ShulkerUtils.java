package com.artillexstudios.axshulkers.utils;

import com.artillexstudios.axshulkers.cache.Shulkerbox;
import com.artillexstudios.axshulkers.cache.Shulkerboxes;
import de.tr7zw.changeme.nbtapi.NBT;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.ShulkerBox;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.BlockStateMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.EnumSet;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

import static com.artillexstudios.axshulkers.AxShulkers.CONFIG;
import static com.artillexstudios.axshulkers.AxShulkers.MESSAGES;

public class ShulkerUtils {
    private static final Set<Material> shulkers = EnumSet.of( // we don't have Tag.SHULKER_BOXES on 1.13
            Material.SHULKER_BOX,
            Material.WHITE_SHULKER_BOX,
            Material.LIGHT_GRAY_SHULKER_BOX,
            Material.GRAY_SHULKER_BOX,
            Material.BLACK_SHULKER_BOX,
            Material.BROWN_SHULKER_BOX,
            Material.RED_SHULKER_BOX,
            Material.ORANGE_SHULKER_BOX,
            Material.YELLOW_SHULKER_BOX,
            Material.LIME_SHULKER_BOX,
            Material.GREEN_SHULKER_BOX,
            Material.CYAN_SHULKER_BOX,
            Material.LIGHT_BLUE_SHULKER_BOX,
            Material.BLUE_SHULKER_BOX,
            Material.PURPLE_SHULKER_BOX,
            Material.MAGENTA_SHULKER_BOX,
            Material.PINK_SHULKER_BOX
    );

    private static final Set<InventoryType> inventories = new HashSet<>();
    static {
        addType("BARREL");
        inventories.add(InventoryType.CRAFTING);
        inventories.add(InventoryType.CREATIVE);
        inventories.add(InventoryType.CHEST);
        inventories.add(InventoryType.DISPENSER);
        inventories.add(InventoryType.DROPPER);
        inventories.add(InventoryType.ENDER_CHEST);
        inventories.add(InventoryType.HOPPER);
        inventories.add(InventoryType.PLAYER);
        inventories.add(InventoryType.SHULKER_BOX);
    }

    private static void addType(String str) {
        try {
            inventories.add(InventoryType.valueOf(str));
        } catch (Exception ignored) {}
    }

    public static boolean isShulker(@Nullable ItemStack it) {
        if (it == null) return false;
        return shulkers.contains(it.getType());
    }

    public static boolean isAllowedInventoryType(@NotNull Inventory inventory) {
        return inventories.contains(inventory.getType());
    }

    @NotNull
    public static ItemStack[] getShulkerItems(@NotNull ItemStack it) {
        final BlockStateMeta im = (BlockStateMeta) it.getItemMeta();
        final ShulkerBox shulker = (ShulkerBox) im.getBlockState();
        final Inventory inv = shulker.getInventory();

        return inv.getContents();
    }

    @Nullable
    public static UUID getShulkerUUID(@Nullable ItemStack it) {
        if (it == null) return null;
        if (it.getType().equals(Material.AIR)) return null;

        final String str = NBT.get(it, nbti -> {
            return nbti.getString(CONFIG.getString("nbt-tag"));
        });

        if (str.isEmpty()) return null;

        return UUID.fromString(str);
    }

    public static final String SEQ_TAG = "AxShulkers-Seq";

    public static void removeShulkerUUID(@NotNull ItemStack it) {
        NBT.modify(it, nbt -> {
            nbt.removeKey(CONFIG.getString("nbt-tag"));
            nbt.removeKey(SEQ_TAG);
        });
    }

    @Nullable
    public static Long getShulkerSeq(@Nullable ItemStack it) {
        if (it == null || it.getType().equals(Material.AIR)) return null;
        return NBT.get(it, nbti -> {
            if (!nbti.hasTag(SEQ_TAG)) return null;
            return nbti.getLong(SEQ_TAG);
        });
    }

    public static void setShulkerSeq(@NotNull ItemStack it, long seq) {
        NBT.modify(it, nbt -> {
            nbt.setLong(SEQ_TAG, seq);
        });
    }

    @NotNull
    public static UUID addShulkerUUID(@NotNull ItemStack it) {
        final UUID uuid = UUID.randomUUID();

        NBT.modify(it, nbt -> {
            nbt.removeKey(SEQ_TAG);
            nbt.setString(CONFIG.getString("nbt-tag"), uuid.toString());
        });
        return uuid;
    }

    public static void setShulkerContents(@NotNull ItemStack it, @NotNull Inventory inventory, boolean bypass) {
        if (!(it.getItemMeta() instanceof BlockStateMeta im)) return;
        if (!(im.getBlockState() instanceof ShulkerBox shulker)) return;

        if (!bypass && CONFIG.getBoolean("enable-obfuscation", false) && !CONFIG.getBoolean("auto-clear-shulkers", false)) {
            shulker.getInventory().clear();
        } else {
            shulker.getInventory().setContents(inventory.getContents());
        }

        im.setBlockState(shulker);
        it.setItemMeta(im);
    }

    public static void clearShulkerContents(@NotNull ItemStack it) {
        if (!(it.getItemMeta() instanceof BlockStateMeta im)) return;
        if (!(im.getBlockState() instanceof ShulkerBox shulker)) return;

        shulker.getInventory().clear();

        im.setBlockState(shulker);
        it.setItemMeta(im);
    }

    public static void setShulkerContents(@NotNull Block block, @NotNull Inventory inventory) {
        if (!(block.getState() instanceof ShulkerBox shulker)) return;

        shulker.getInventory().setContents(inventory.getContents());
        block.setBlockData(shulker.getBlockData());
    }

    public static void clearShulkerContents(@NotNull Block block) {
        if (!(block.getState() instanceof ShulkerBox shulker)) return;

        shulker.getInventory().clear();
        block.setBlockData(shulker.getBlockData());
    }

    public static String getShulkerName(@NotNull ItemStack it) {
        ItemMeta meta = it.getItemMeta();
        if (meta == null || meta.getDisplayName().isEmpty()) {
            return ColorUtils.format(MESSAGES.getString("shulker-title"));
        }
        return meta.getDisplayName();
    }

    @Nullable
    public static Shulkerbox getOpenShulker(@NotNull Player player) {
        Inventory inventory = player.getOpenInventory().getTopInventory();
        for (Shulkerbox shulkerbox : Shulkerboxes.getShulkerMap().values()) {
            if (!shulkerbox.getShulkerInventory().equals(inventory)) continue;
            return shulkerbox;
        }
        return null;
    }
}
